<?php
/**
 * Archive Template (category, tag, date, author)
 * @package AutoMotoNews_Future
 */
get_header(); ?>

<main id="main-content" role="main" class="site-shell archive-main">

  <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'automotonews-future' ); ?>">
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'automotonews-future' ); ?></a></li>
      <li class="breadcrumb-current" aria-current="page"><?php the_archive_title(); ?></li>
    </ol>
  </nav>

  <header class="archive-header">
    <h1><?php the_archive_title(); ?></h1>
    <?php if ( get_the_archive_description() ) : ?>
      <p class="archive-description"><?php echo wp_kses_post( get_the_archive_description() ); ?></p>
    <?php endif; ?>
  </header>

  <?php if ( have_posts() ) : ?>
  <div class="card-grid three" role="list">
    <?php while ( have_posts() ) : the_post();
      $cat      = get_the_category();
      $cat_name = $cat ? esc_html( $cat[0]->name ) : '';
      $cat_url  = $cat ? esc_url( get_category_link( $cat[0]->term_id ) ) : '#';
      $read_time = amnf_read_time( get_the_ID() );
    ?>
    <article class="news-card glass" role="listitem" itemscope itemtype="https://schema.org/NewsArticle">
      <a href="<?php the_permalink(); ?>" class="card-img-link" tabindex="-1" aria-hidden="true">
        <?php if ( has_post_thumbnail() ) :
          the_post_thumbnail( 'amnf-card', array( 'alt' => get_the_title(), 'loading' => 'lazy', 'class' => 'card-img' ) );
        else : ?>
          <div class="card-img-placeholder" aria-hidden="true"></div>
        <?php endif; ?>
      </a>
      <div class="card-body">
        <?php if ( $cat_name ) : ?>
          <a href="<?php echo $cat_url; ?>" class="cat-badge"><?php echo $cat_name; ?></a>
        <?php endif; ?>
        <h2 class="card-title" itemprop="headline">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <p class="card-excerpt"><?php the_excerpt(); ?></p>
        <a href="<?php the_permalink(); ?>" class="btn-read-more" aria-label="<?php printf( esc_attr__( 'Read more about %s', 'automotonews-future' ), get_the_title() ); ?>"><?php esc_html_e( 'Read more', 'automotonews-future' ); ?></a>
        <div class="card-meta">
          <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished"><?php echo get_the_date( 'M j, Y' ); ?></time>
          <span class="read-time"><?php echo esc_html( $read_time ); ?></span>
        </div>
      </div>
    </article>
    <?php endwhile; ?>
  </div>

  <nav class="pagination-wrap" aria-label="<?php esc_attr_e( 'Posts pagination', 'automotonews-future' ); ?>">
    <?php the_posts_pagination( array(
        'mid_size'  => 2,
        'prev_text' => '&larr; ' . __( 'Previous', 'automotonews-future' ),
        'next_text' => __( 'Next', 'automotonews-future' ) . ' &rarr;',
    ) ); ?>
  </nav>

  <?php else : ?>
  <div class="no-posts glass">
    <h2><?php esc_html_e( 'No posts found', 'automotonews-future' ); ?></h2>
    <p><?php esc_html_e( 'Try a different category or search below.', 'automotonews-future' ); ?></p>
    <?php get_search_form(); ?>
  </div>
  <?php endif; ?>

</main>

<?php get_footer(); ?>
