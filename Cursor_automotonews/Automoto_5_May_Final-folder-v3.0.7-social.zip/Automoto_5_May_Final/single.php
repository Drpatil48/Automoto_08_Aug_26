<?php
/**
 * Single Post Template
 * @package AutoMotoNews_Future
 */
get_header();
while ( have_posts() ) : the_post();
    $cat       = get_the_category();
    $cat_name  = $cat ? esc_html( $cat[0]->name ) : '';
    $cat_url   = $cat ? get_category_link( $cat[0]->term_id ) : '#';
    $read_time = amnf_read_time( get_the_ID() );
?>
<main id="main-content" role="main" class="single-main site-shell">

  <!-- Breadcrumb -->
  <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'automotonews-future' ); ?>">
    <ol itemscope itemtype="https://schema.org/BreadcrumbList">
      <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span itemprop="name"><?php esc_html_e( 'Home', 'automotonews-future' ); ?></span></a>
        <meta itemprop="position" content="1">
      </li>
      <?php if ( $cat_name ) : ?>
      <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="<?php echo esc_url( $cat_url ); ?>"><span itemprop="name"><?php echo $cat_name; ?></span></a>
        <meta itemprop="position" content="2">
      </li>
      <?php endif; ?>
      <li class="breadcrumb-current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <span itemprop="name"><?php the_title(); ?></span>
        <meta itemprop="position" content="<?php echo $cat_name ? '3' : '2'; ?>">
      </li>
    </ol>
  </nav>

  <article class="single-article" itemscope itemtype="https://schema.org/NewsArticle">

    <!-- Article Header -->
    <header class="article-header">
      <?php if ( $cat_name ) : ?>
      <a href="<?php echo esc_url( $cat_url ); ?>" class="cat-badge" itemprop="articleSection"><?php echo $cat_name; ?></a>
      <?php endif; ?>
      <h1 class="article-title" itemprop="headline"><?php the_title(); ?></h1>
      <div class="article-meta" aria-label="<?php esc_attr_e( 'Article information', 'automotonews-future' ); ?>">
        <span class="meta-author" itemprop="author" itemscope itemtype="https://schema.org/Person">
          <span itemprop="name"><?php the_author(); ?></span>
        </span>
        <time class="meta-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished"><?php echo get_the_date( 'F j, Y' ); ?></time>
        <?php if ( get_the_modified_date( 'c' ) !== get_the_date( 'c' ) ) : ?>
        <time class="meta-date meta-date--modified" datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>" itemprop="dateModified"><?php printf( esc_html__( 'Updated %s', 'automotonews-future' ), get_the_modified_date( 'F j, Y' ) ); ?></time>
        <?php endif; ?>
        <span class="meta-read-time"><?php echo esc_html( $read_time ); ?></span>
      </div>
    </header>

    <!-- Featured Image -->
    <?php if ( has_post_thumbnail() ) : ?>
    <figure class="article-featured-image" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
      <?php
      $thumb_id = get_post_thumbnail_id();
      $thumb_url = get_the_post_thumbnail_url( null, 'amnf-wide' );
      the_post_thumbnail( 'amnf-wide', array(
          'alt'      => get_the_title(),
          'loading'  => 'eager',
          'itemprop' => 'url',
      ) );
      if ( $thumb_url ) {
          echo '<meta itemprop="contentUrl" content="' . esc_url( $thumb_url ) . '">';
      }
      ?>
      <?php if ( get_the_post_thumbnail_caption() ) : ?>
        <figcaption itemprop="caption"><?php echo wp_kses_post( get_the_post_thumbnail_caption() ); ?></figcaption>
      <?php endif; ?>
    </figure>
    <?php endif; ?>

    <!-- Article Content -->
    <div class="article-content" itemprop="articleBody">
      <?php the_content(); ?>
      <?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'automotonews-future' ), 'after' => '</div>' ) ); ?>
    </div>

    <?php amnf_ad_slot( 'single_after_content' ); ?>

    <!-- Tags -->
    <?php $tags = get_the_tags(); if ( $tags ) : ?>
    <div class="article-tags" aria-label="<?php esc_attr_e( 'Article tags', 'automotonews-future' ); ?>">
      <?php foreach ( $tags as $tag ) : ?>
        <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="tag-chip" rel="tag"><?php echo esc_html( $tag->name ); ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Author Box -->
    <div class="author-box glass" itemscope itemtype="https://schema.org/Person">
      <div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 60, '', get_the_author(), array( 'class' => 'author-img' ) ); ?></div>
      <div>
        <strong itemprop="name"><?php the_author(); ?></strong>
        <p itemprop="description"><?php the_author_meta( 'description' ); ?></p>
      </div>
    </div>

    <!-- Previous / Next Navigation -->
    <nav class="post-navigation" aria-label="<?php esc_attr_e( 'Post navigation', 'automotonews-future' ); ?>">
      <?php the_post_navigation( array(
          'prev_text' => '<span class="nav-label">' . __( 'Previous', 'automotonews-future' ) . '</span><span class="nav-title">%title</span>',
          'next_text' => '<span class="nav-label">' . __( 'Next', 'automotonews-future' ) . '</span><span class="nav-title">%title</span>',
      ) ); ?>
    </nav>

  </article>

  <!-- Comments -->
  <?php if ( comments_open() || get_comments_number() ) : ?>
  <section class="comments-section glass" aria-label="<?php esc_attr_e( 'Comments', 'automotonews-future' ); ?>">
    <?php comments_template(); ?>
  </section>
  <?php endif; ?>

</main>

<?php endwhile; get_footer(); ?>
