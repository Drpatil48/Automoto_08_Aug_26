/* jshint esversion: 6 */
'use strict';

(function () {

  // ── Dark Mode Toggle ─────────────────────────────────────────────────
  var DARK_KEY = 'amnf-dark-mode';
  var toggleBtn = document.getElementById('dark-mode-toggle');
  var body = document.body;
  var htmlEl = document.documentElement;

  // Apply saved preference immediately
  function applyDarkMode(enabled) {
    if (enabled) {
      body.classList.add('dark-mode');
      htmlEl.classList.remove('dark-mode-loading'); // cleanup anti-flash class
      if (toggleBtn) toggleBtn.setAttribute('aria-label', 'Switch to light mode');
    } else {
      body.classList.remove('dark-mode');
      htmlEl.classList.remove('dark-mode-loading');
      if (toggleBtn) toggleBtn.setAttribute('aria-label', 'Switch to dark mode');
    }
  }

  // Read stored preference
  var savedMode = 'disabled';
  try { savedMode = localStorage.getItem(DARK_KEY) || 'disabled'; } catch(e) {}
  applyDarkMode(savedMode === 'enabled');

  // Toggle on click
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function () {
      var isDark = body.classList.contains('dark-mode');
      var newMode = isDark ? 'disabled' : 'enabled';
      try { localStorage.setItem(DARK_KEY, newMode); } catch(e) {}
      applyDarkMode(newMode === 'enabled');
    });
  }


  // ── Compare Tool ───────────────────────────────────────────────────
  function vehicleImg(photoId) {
    return 'https://images.unsplash.com/' + photoId + '?auto=format&fit=crop&w=640&h=360&q=80';
  }

  const vehicles = [
    //                                                                                    power  torque  topSpd  boot  stars
    { name: 'Tata Nexon EV',        price: 14.49, priceStr: '₹14.49L', range: 465,  rangeStr: '465 km',   fuel: 'Electric', cat: 'SUV',        power: 143, powerStr: '143 bhp', torque: 215, torqueStr: '215 Nm', topSpd: 150, topSpdStr: '150 km/h', boot: 350, bootStr: '350 L',  stars: 5, starsStr: '5★ (GNCAP)', img: vehicleImg('photo-1618843479313-40f8afb4b4d8') },
    { name: 'Hyundai Creta EV',     price: 17.99, priceStr: '₹17.99L', range: 473,  rangeStr: '473 km',   fuel: 'Electric', cat: 'SUV',        power: 171, powerStr: '171 bhp', torque: 255, torqueStr: '255 Nm', topSpd: 175, topSpdStr: '175 km/h', boot: 433, bootStr: '433 L',  stars: 5, starsStr: '5★ (GNCAP)', img: vehicleImg('photo-1549924231-f129b911e442') },
    { name: 'MG Windsor EV',        price: 13.50, priceStr: '₹13.50L', range: 331,  rangeStr: '331 km',   fuel: 'Electric', cat: 'SUV',        power: 136, powerStr: '136 bhp', torque: 200, torqueStr: '200 Nm', topSpd: 160, topSpdStr: '160 km/h', boot: 604, bootStr: '604 L',  stars: 0, starsStr: 'Not Rated', img: vehicleImg('photo-1492144534655-ae79c964c9d7') },
    { name: 'Mahindra BE 6',        price: 18.90, priceStr: '₹18.90L', range: 556,  rangeStr: '556 km',   fuel: 'Electric', cat: 'SUV',        power: 228, powerStr: '228 bhp', torque: 380, torqueStr: '380 Nm', topSpd: 201, topSpdStr: '201 km/h', boot: 455, bootStr: '455 L',  stars: 5, starsStr: '5★ (BNCAP)', img: vehicleImg('photo-1493238792000-8113da705763') },
    { name: 'BYD Seal',             price: 41.00, priceStr: '₹41.00L', range: 650,  rangeStr: '650 km',   fuel: 'Electric', cat: 'Sedan',      power: 530, powerStr: '530 bhp', torque: 670, torqueStr: '670 Nm', topSpd: 180, topSpdStr: '180 km/h', boot: 400, bootStr: '400 L',  stars: 5, starsStr: '5★ (Euro NCAP)', img: vehicleImg('photo-1614209184924-58687e983e8e') },
    { name: 'Maruti Swift',         price: 6.49,  priceStr: '₹6.49L',  range: 22,   rangeStr: '22 kmpl',  fuel: 'Petrol',   cat: 'Hatchback',  power: 82,  powerStr: '82 bhp',  torque: 112, torqueStr: '112 Nm', topSpd: 160, topSpdStr: '160 km/h', boot: 268, bootStr: '268 L',  stars: 3, starsStr: '3★ (GNCAP)', img: vehicleImg('photo-1542362567-b07e54308753') },
    { name: 'Hyundai Creta Petrol', price: 11.00, priceStr: '₹11.00L', range: 16,   rangeStr: '16 kmpl',  fuel: 'Petrol',   cat: 'SUV',        power: 115, powerStr: '115 bhp', torque: 144, torqueStr: '144 Nm', topSpd: 172, topSpdStr: '172 km/h', boot: 433, bootStr: '433 L',  stars: 5, starsStr: '5★ (GNCAP)', img: vehicleImg('photo-1606664515524-d06866e5458a') },
    { name: 'Toyota Innova Crysta', price: 19.99, priceStr: '₹19.99L', range: 15,   rangeStr: '15 kmpl',  fuel: 'Diesel',   cat: 'MPV',        power: 150, powerStr: '150 bhp', torque: 360, torqueStr: '360 Nm', topSpd: 170, topSpdStr: '170 km/h', boot: 300, bootStr: '300 L',  stars: 0, starsStr: 'Not Rated', img: vehicleImg('photo-1519641471654-76ce574ebc0b') },
    { name: 'Honda City Hybrid',    price: 19.49, priceStr: '₹19.49L', range: 27,   rangeStr: '27 kmpl',  fuel: 'Hybrid',   cat: 'Sedan',      power: 126, powerStr: '126 bhp', torque: 253, torqueStr: '253 Nm', topSpd: 180, topSpdStr: '180 km/h', boot: 506, bootStr: '506 L',  stars: 4, starsStr: '4★ (JNCAP)', img: vehicleImg('photo-1555215695-3004980ad54e') },
    { name: 'Royal Enfield Classic 350', price: 1.93, priceStr: '₹1.93L', range: 35, rangeStr: '35 kmpl', fuel: 'Petrol',   cat: 'Motorcycle', power: 20,  powerStr: '20 bhp',  torque: 27,  torqueStr: '27 Nm',  topSpd: 110, topSpdStr: '110 km/h', boot: 0,   bootStr: 'N/A',     stars: 0, starsStr: 'N/A', img: vehicleImg('photo-1568772585407-9361f9bf3a87') },
    { name: 'TVS iQube S',          price: 1.38,  priceStr: '₹1.38L',  range: 145,  rangeStr: '145 km',   fuel: 'Electric', cat: 'Scooter',    power: 4,   powerStr: '4.4 bhp', torque: 140, torqueStr: '140 Nm', topSpd: 82,  topSpdStr: '82 km/h',  boot: 0,   bootStr: 'N/A',     stars: 0, starsStr: 'N/A', img: vehicleImg('photo-1623071291121-9f0d17f32190') },
    { name: 'Ola S1 Pro',           price: 1.47,  priceStr: '₹1.47L',  range: 181,  rangeStr: '181 km',   fuel: 'Electric', cat: 'Scooter',    power: 8,   powerStr: '8.5 bhp', torque: 58,  torqueStr: '58 Nm',  topSpd: 120, topSpdStr: '120 km/h', boot: 0,   bootStr: 'N/A',     stars: 0, starsStr: 'N/A', img: vehicleImg('photo-1558980664-10ea2f97f7c1') },
    { name: 'Honda Activa 6G',      price: 0.748, priceStr: '₹74,800', range: 50,   rangeStr: '50 kmpl',  fuel: 'Petrol',   cat: 'Scooter',    power: 8,   powerStr: '7.7 bhp', torque: 9,   torqueStr: '8.8 Nm', topSpd: 85,  topSpdStr: '85 km/h',  boot: 18,  bootStr: '18 L',    stars: 0, starsStr: 'N/A', img: vehicleImg('photo-1558981806-ec527fa84c39') },
    { name: 'Tata Punch EV',        price: 9.99,  priceStr: '₹9.99L',  range: 421,  rangeStr: '421 km',   fuel: 'Electric', cat: 'SUV',        power: 122, powerStr: '122 bhp', torque: 190, torqueStr: '190 Nm', topSpd: 140, topSpdStr: '140 km/h', boot: 366, bootStr: '366 L',  stars: 5, starsStr: '5★ (GNCAP)', img: vehicleImg('photo-16055594259-1eb5dfe5b71e') },
    { name: 'Kia Seltos',           price: 11.00, priceStr: '₹11.00L', range: 16,   rangeStr: '16 kmpl',  fuel: 'Petrol',   cat: 'SUV',        power: 115, powerStr: '115 bhp', torque: 144, torqueStr: '144 Nm', topSpd: 170, topSpdStr: '170 km/h', boot: 433, bootStr: '433 L',  stars: 3, starsStr: '3★ (GNCAP)', img: vehicleImg('photo-1606664515524-d06866e5458a') },
  ];

  function populateSelect(selectEl) {
    vehicles.forEach(function (v, i) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = v.name;
      selectEl.appendChild(opt);
    });
  }

  const selA = document.getElementById('modelA');
  const selB = document.getElementById('modelB');
  const compareBtn = document.getElementById('compareButton');
  const compareResult = document.getElementById('compareResult');

  // ── Confetti burst ───────────────────────────────────────────────────
  function launchConfetti(container) {
    var colors = ['#e60000','#ff6b6b','#ffd700','#ffffff','#22c55e','#3b82f6'];
    for (var ci = 0; ci < 70; ci++) {
      (function(i) {
        var dot = document.createElement('div');
        dot.className = 'confetti-dot';
        var size = Math.random() * 9 + 4;
        dot.style.cssText = [
          'position:absolute',
          'width:' + size + 'px',
          'height:' + size + 'px',
          'background:' + colors[Math.floor(Math.random() * colors.length)],
          'border-radius:' + (Math.random() > 0.4 ? '50%' : '2px'),
          'left:' + (Math.random() * 100) + '%',
          'top:20px',
          'pointer-events:none',
          'z-index:200',
          'animation:confetti-fall ' + (Math.random() * 1.8 + 0.6) + 's cubic-bezier(0.25,0.46,0.45,0.94) ' + (i * 25) + 'ms forwards'
        ].join(';');
        container.appendChild(dot);
        setTimeout(function() { if (dot.parentNode) dot.parentNode.removeChild(dot); }, 4000);
      })(ci);
    }
  }

  // ── Price count-up ───────────────────────────────────────────────────
  function animatePriceEl(el, targetVal, suffix) {
    var start = null;
    var duration = 1400;
    function step(ts) {
      if (!start) start = ts;
      var progress = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 4);
      el.textContent = '₹' + (eased * targetVal).toFixed(2) + suffix;
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = '₹' + targetVal.toFixed(2) + suffix;
    }
    requestAnimationFrame(step);
  }

  // ── Fuel color helper ────────────────────────────────────────────────
  function fuelClass(f) {
    if (f === 'Electric') return 'badge-ev';
    if (f === 'Petrol')   return 'badge-petrol';
    if (f === 'Diesel')   return 'badge-diesel';
    if (f === 'Hybrid')   return 'badge-hybrid';
    return '';
  }

  // ── Vehicle result card (text only — no photos) ──────────────────────
  function vehicleResultCard(v, isWinner, side) {
    var sideClass = side === 'a' ? 'cmp-veh-a' : 'cmp-veh-b';
    // #region agent log
    fetch('http://127.0.0.1:7775/ingest/c91f9762-5d87-4725-adef-0ed6fc650623',{method:'POST',headers:{'Content-Type':'application/json','X-Debug-Session-Id':'35d4da'},body:JSON.stringify({sessionId:'35d4da',runId:'cmp-badge-layout',hypothesisId:'H1',location:'main.js:vehicleResultCard',message:'Compare tile badge layout',data:{side:side,isWinner:!!isWinner,fuel:v.fuel,badgeRow:'inline'},timestamp:Date.now()})}).catch(function(){});
    // #endregion
    return (
      '<article class="cmp-veh ' + sideClass + (isWinner ? ' cmp-veh-winner' : '') + '">' +
        '<div class="cmp-veh-body">' +
          '<div class="cmp-veh-badges">' +
            '<span class="cmp-fuel-badge ' + fuelClass(v.fuel) + '">' + v.fuel + '</span>' +
            (isWinner ? '<span class="cmp-winner-badge" aria-label="Best overall pick">Best pick</span>' : '') +
          '</div>' +
          '<h3 class="cmp-veh-name">' + v.name + '</h3>' +
          '<p class="cmp-veh-price">' + v.priceStr + '</p>' +
        '</div>' +
      '</article>'
    );
  }

  // ── Editorial spec row (center-radiating bars) ───────────────────────
  function specRowCenter(icon, label, aVal, bVal, aStr, bStr, higherIsBetter) {
    var maxVal = Math.max(aVal, bVal) || 1;
    var aPct = Math.round((aVal / maxVal) * 100);
    var bPct = Math.round((bVal / maxVal) * 100);
    var aWin = higherIsBetter ? aVal >= bVal : aVal <= bVal;
    var bWin = !aWin || aVal === bVal;
    // If equal, no winner
    if (aVal === bVal) { aWin = false; bWin = false; }

    var aValId = 'sv-a-' + label.replace(/\s/g,'');
    var bValId = 'sv-b-' + label.replace(/\s/g,'');

    return (
      '<div class="cmp-spec-row' + (aWin ? ' row-a-wins' : bWin ? ' row-b-wins' : '') + '">' +
        '<div class="cmp-spec-side cmp-spec-side-a">' +
          '<div class="cmp-spec-val' + (aWin ? ' val-winner' : '') + '" id="' + aValId + '">' + aStr + '</div>' +
          '<div class="cmp-bar-track">' +
            '<div class="cmp-bar-fill cmp-bar-a" style="--bw:' + aPct + '%">' +
              (aWin ? '<div class="cmp-bar-glow"></div>' : '') +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="cmp-spec-center">' +
          '<div class="cmp-spec-icon">' + icon + '</div>' +
          '<div class="cmp-spec-lbl">' + label + '</div>' +
        '</div>' +
        '<div class="cmp-spec-side cmp-spec-side-b">' +
          '<div class="cmp-bar-track">' +
            '<div class="cmp-bar-fill cmp-bar-b" style="--bw:' + bPct + '%">' +
              (bWin ? '<div class="cmp-bar-glow"></div>' : '') +
            '</div>' +
          '</div>' +
          '<div class="cmp-spec-val' + (bWin ? ' val-winner val-winner-b' : '') + '" id="' + bValId + '">' + bStr + '</div>' +
        '</div>' +
      '</div>'
    );
  }

  // ── Comparison summary text ──────────────────────────────────────────
  function generateAnalysis(a, b) {
    var lines = [];
    var aName = '<span class="pa-name pa-name-a">' + a.name + '</span>';
    var bName = '<span class="pa-name pa-name-b">' + b.name + '</span>';

    // Power/torque sentence
    if (a.power > b.power) {
      lines.push('The ' + aName + ' dominates in power and acceleration' +
        (a.fuel === 'Electric' ? ', utilizing immediate electric motor delivery' : '') + '.');
    } else if (b.power > a.power) {
      lines.push('The ' + bName + ' leads in raw power output' +
        (b.fuel === 'Electric' ? ', thanks to instant electric torque' : '') + '.');
    }

    // Range sentence
    if (a.range > b.range) {
      lines.push('With ' + a.rangeStr + ' range, ' + aName + ' is the better choice for longer journeys.');
    } else if (b.range > a.range) {
      lines.push('The ' + bName + ' offers superior range at ' + b.rangeStr + ', ideal for long-distance rides.');
    }

    // Price / value sentence
    if (a.price < b.price) {
      lines.push('The ' + bName + ' remains the premium pick, while ' + aName + ' wins on affordability.');
    } else if (b.price < a.price) {
      lines.push('The ' + aName + ' is the pricier option; ' + bName + ' offers better value for money.');
    }

    // Safety
    if (a.stars > b.stars) {
      lines.push(aName + ' has a stronger safety record with a ' + a.starsStr + ' crash test rating.');
    } else if (b.stars > a.stars) {
      lines.push(bName + ' provides better occupant safety with a ' + b.starsStr + ' rating.');
    }

    if (lines.length === 0) lines.push('Both ' + aName + ' and ' + bName + ' offer competitive specs in their segment.');
    return lines.join(' ');
  }

  function runCompare() {
    const a = vehicles[parseInt(selA.value, 10)];
    const b = vehicles[parseInt(selB.value, 10)];
    if (!a || !b) return;

    var aScore = (1 / a.price) * 40 + a.range * 0.08 + a.power * 0.05;
    var bScore = (1 / b.price) * 40 + b.range * 0.08 + b.power * 0.05;
    var aWinsOverall = aScore > bScore;
    var bWinsOverall = bScore > aScore;
    var overallWinner = aWinsOverall ? a.name : (bWinsOverall ? b.name : null);
    var siteUrl = (typeof amnfData !== 'undefined' && amnfData.siteUrl) ? amnfData.siteUrl : '/';

    compareResult.innerHTML =
      '<div class="cmp-root">' +
        '<div class="cmp-vehicles">' +
          vehicleResultCard(a, aWinsOverall, 'a') +
          '<div class="cmp-vs-divider" aria-hidden="true"><span>vs</span></div>' +
          vehicleResultCard(b, bWinsOverall, 'b') +
        '</div>' +
        '<div class="cmp-specs">' +
          specRowCenter('₹', 'Price', a.price, b.price, a.priceStr, b.priceStr, false) +
          specRowCenter('⚡', 'Range', a.range, b.range, a.rangeStr, b.rangeStr, true) +
          specRowCenter('⚙️', 'Power', a.power, b.power, a.powerStr, b.powerStr, true) +
          specRowCenter('🔩', 'Torque', a.torque, b.torque, a.torqueStr, b.torqueStr, true) +
          specRowCenter('🚀', 'Top speed', a.topSpd, b.topSpd, a.topSpdStr, b.topSpdStr, true) +
          (a.boot > 0 || b.boot > 0 ? specRowCenter('📦', 'Boot space', a.boot, b.boot, a.bootStr, b.bootStr, true) : '') +
          (a.stars > 0 || b.stars > 0 ? specRowCenter('🛡️', 'Safety', a.stars, b.stars, a.starsStr, b.starsStr, true) : '') +
        '</div>' +
        '<div class="cmp-summary">' +
          '<h3 class="cmp-summary-title">Our take</h3>' +
          '<p class="cmp-summary-body">' + generateAnalysis(a, b) + '</p>' +
          '<a href="' + siteUrl + '?s=' + encodeURIComponent(a.name + ' review') + '" class="cmp-cta-btn">Read reviews &rarr;</a>' +
        '</div>' +
      '</div>';

    compareResult.classList.remove('compare-result--loading');
    compareResult.removeAttribute('aria-busy');

    requestAnimationFrame(function () {
      compareResult.querySelectorAll('.cmp-bar-fill').forEach(function (bar) {
        bar.classList.add('animate');
      });
    });

    var priceA = compareResult.querySelector('#sv-a-Price');
    var priceB = compareResult.querySelector('#sv-b-Price');
    if (priceA && a.price >= 1) animatePriceEl(priceA, a.price, 'L');
    if (priceB && b.price >= 1) animatePriceEl(priceB, b.price, 'L');

    if (overallWinner) launchConfetti(compareResult.querySelector('.cmp-root'));
  }

  if (selA && selB && compareBtn && compareResult) {
    populateSelect(selA);
    populateSelect(selB);
    selA.value = 0;
    selB.value = 1;

    compareBtn.addEventListener('click', runCompare);
    runCompare();
  }

  // ── Mobile Navigation Toggle ─────────────────────────────────────────
  var menuToggle = document.getElementById('menu-toggle');
  var secondaryNavBar = document.getElementById('secondary-nav-bar');
  if (menuToggle && secondaryNavBar) {
    menuToggle.addEventListener('click', function () {
      var isOpen = secondaryNavBar.classList.toggle('nav-open');
      menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) {
      if (!secondaryNavBar.classList.contains('nav-open')) return;
      if (!secondaryNavBar.contains(e.target) && !menuToggle.contains(e.target)) {
        secondaryNavBar.classList.remove('nav-open');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && secondaryNavBar.classList.contains('nav-open')) {
        secondaryNavBar.classList.remove('nav-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.focus();
      }
    });
  }

  // ── Featured Card subtle parallax scroll ────────────────────────────
  var tlBg = document.querySelector('.tl-featured-bg');
  if (tlBg && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.addEventListener('scroll', function() {
      var card = tlBg.parentElement;
      if (!card) return;
      var rect = card.getBoundingClientRect();
      if (rect.bottom < 0 || rect.top > window.innerHeight) return;
      var pct = (rect.top / window.innerHeight) * 20; // max 20px shift
      tlBg.style.transform = 'translateY(' + pct + 'px)';
    }, { passive: true });
  }

  // ── Newsletter Form (basic UX) ──────────────────────────────────────

  const newsletterForm = document.querySelector('.newsletter-form');
  const newsletterMsg = document.getElementById('newsletter-msg');
  if (newsletterForm && newsletterMsg) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const emailInput = newsletterForm.querySelector('input[type="email"]');
      const consentInput = document.getElementById('newsletter-consent');
      const email = emailInput ? emailInput.value.trim() : '';
      var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      if (!emailOk) {
        newsletterMsg.textContent = 'Please enter a valid email address.';
        newsletterMsg.style.color = '#e60000';
        if (emailInput) emailInput.setAttribute('aria-invalid', 'true');
        return;
      }
      if (consentInput && !consentInput.checked) {
        newsletterMsg.textContent = 'Please accept the Privacy Policy to subscribe.';
        newsletterMsg.style.color = '#e60000';
        return;
      }
      if (emailInput) emailInput.removeAttribute('aria-invalid');
      newsletterMsg.style.color = '';
      newsletterMsg.textContent = 'Thanks! You\'re subscribed.';
      newsletterForm.reset();
      setTimeout(function () { newsletterMsg.textContent = ''; }, 4000);
    });
  }

  // ── Cookie consent (AdSense) ─────────────────────────────────────────
  var cookieBanner = document.getElementById('amnf-cookie-consent');
  var cookieAccept = document.getElementById('amnf-cookie-accept');
  var cookieKey = 'amnf_cookie_consent';
  if (cookieBanner && cookieAccept) {
    try {
      if (!localStorage.getItem(cookieKey)) {
        cookieBanner.removeAttribute('hidden');
      }
    } catch (err) {
      cookieBanner.removeAttribute('hidden');
    }
    cookieAccept.addEventListener('click', function () {
      try {
        localStorage.setItem(cookieKey, '1');
      } catch (err) { /* ignore */ }
      cookieBanner.setAttribute('hidden', '');
    });
  }


  // ── Back to Top Button ─────────────────────────────────────────────
  var backToTop = document.getElementById('back-to-top');
  if (!backToTop) {
    backToTop = document.createElement('button');
    backToTop.id = 'back-to-top';
    backToTop.className = 'back-to-top';
    backToTop.setAttribute('aria-label', 'Scroll to top');
    backToTop.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>';
    document.body.appendChild(backToTop);
  }

  backToTop.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // ── Reading Progress Bar ───────────────────────────────────────────
  var progressBar = document.getElementById('reading-progress');
  if (!progressBar) {
    progressBar = document.createElement('div');
    progressBar.id = 'reading-progress';
    progressBar.className = 'reading-progress';
    document.body.prepend(progressBar);
  }

  // ── Scroll Handler (combined for performance) ──────────────────────
  var ticking = false;
  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        var docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;

        // Back to top visibility
        if (backToTop) {
          if (scrollTop > 400) {
            backToTop.classList.add('visible');
          } else {
            backToTop.classList.remove('visible');
          }
        }

        // Reading progress
        if (progressBar && docHeight > 0) {
          var progress = (scrollTop / docHeight) * 100;
          progressBar.style.width = progress + '%';
        }

        ticking = false;

      });
      ticking = true;
    }
  });

  // ── Animated Stats Counter ─────────────────────────────────────────
  var statNumbers = document.querySelectorAll('.stat-number');
  if (statNumbers.length && 'IntersectionObserver' in window) {
    var statsBar = document.getElementById('stats-bar');
    var statsAnimated = false;

    function easeOutQuad(t) { return t * (2 - t); }

    function animateCounter(el) {
      var target  = parseInt(el.getAttribute('data-target'), 10);
      var suffix  = el.getAttribute('data-suffix') || '';
      if (isNaN(target)) return;
      // Skip animation if server already rendered the final value (progressive enhancement)
      var existing = parseInt(el.textContent, 10);
      if (!isNaN(existing) && existing >= target && target > 0) return;

      var duration = 1800;
      var start   = null;
      el.textContent = '0' + suffix;

      function step(timestamp) {
        if (!start) start = timestamp;
        var elapsed  = timestamp - start;
        var progress = Math.min(elapsed / duration, 1);
        var eased    = easeOutQuad(progress);
        var current  = Math.round(eased * target);
        el.textContent = current + suffix;
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target + suffix;
        }
      }
      requestAnimationFrame(step);
    }

    var statsObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting && !statsAnimated) {
          statsAnimated = true; // only animate once
          statNumbers.forEach(function (el) {
            animateCounter(el);
          });
          statsObserver.disconnect();
        }
      });
    }, { threshold: 0.4 });

    if (statsBar) statsObserver.observe(statsBar);
  }

  // ── Blur-Up Lazy Loading ───────────────────────────────────────────
  // Works with native loading="lazy" — adds blur until image is decoded
  var blurUpImages = document.querySelectorAll('img[loading="lazy"]');
  blurUpImages.forEach(function (img) {
    // Skip feature-card images — they already have their own overlay
    if (img.closest('.feature-card')) return;

    img.classList.add('blur-up');

    if (img.complete && img.naturalWidth > 0) {
      img.classList.add('blur-up-loaded');
      return;
    }
    img.addEventListener('load', function () {
      img.classList.add('blur-up-loaded');
    });
    img.addEventListener('error', function () {
      img.classList.add('blur-up-loaded'); // clear blur even on error
    });
  });

  // ── Skeleton Loading: remove shimmer when images finish loading ────
  var skeletonLinks = document.querySelectorAll('.card-img-link');
  skeletonLinks.forEach(function (link) {
    var img = link.querySelector('img');
    if (!img) return;

    // Already loaded (cached)
    if (img.complete && img.naturalWidth > 0) {
      link.classList.add('img-loaded');
      return;
    }
    // Load event
    img.addEventListener('load', function () {
      link.classList.add('img-loaded');
    });
    // Error — still remove shimmer so it doesn't freeze
    img.addEventListener('error', function () {
      link.classList.add('img-loaded');
    });
  });

  // Mark page as ready (no opacity hijacking — CSS handles visibility)
  document.body.classList.add('page-ready');

})();
