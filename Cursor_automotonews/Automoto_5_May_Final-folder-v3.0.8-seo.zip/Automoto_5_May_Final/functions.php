<?php
/**
 * AutoMotoNews Future — Theme Functions
 *
 * @package AutoMotoNews_Future
 * @version 3.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once get_template_directory() . '/inc/seo.php';

// ─── Theme Setup ─────────────────────────────────────────────────────────────
function amnf_setup() {
    // Language support
    load_theme_textdomain( 'automotonews-future', get_template_directory() . '/languages' );

    // HTML5 support
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

    // Title tag (required for SEO)
    add_theme_support( 'title-tag' );

    // Featured images — CRITICAL for card thumbnails
    add_theme_support( 'post-thumbnails' );

    // Custom image sizes
    add_image_size( 'amnf-card',      640, 360, true );  // 16:9 news card
    add_image_size( 'amnf-feature',   760, 430, true );  // Hero/feature card
    add_image_size( 'amnf-wide',     1120, 630, true );  // Full-width hero 16:9
    add_image_size( 'amnf-mini',      320, 180, true );  // Guide mini card 16:9
    add_image_size( 'amnf-story',     120,  68, true );  // Top Stories thumb 16:9

    // RSS feed links
    add_theme_support( 'automatic-feed-links' );

    // Wide/full block alignment
    add_theme_support( 'align-wide' );

    // Custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 50,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Register nav menus
    register_nav_menus( array(
        'primary'  => __( 'Primary Navigation', 'automotonews-future' ),
        'footer'   => __( 'Footer Navigation', 'automotonews-future' ),
    ) );

    // Block editor color palette (Clean Editorial)
    add_theme_support( 'editor-color-palette', array(
        array( 'name' => __( 'Primary Accent', 'automotonews-future' ), 'slug' => 'accent', 'color' => '#B3251E' ),
        array( 'name' => __( 'EV Accent', 'automotonews-future' ),      'slug' => 'ev',     'color' => '#0F6E5C' ),
        array( 'name' => __( 'Ink', 'automotonews-future' ),            'slug' => 'text',   'color' => '#1A1A1A' ),
        array( 'name' => __( 'Warm Paper', 'automotonews-future' ),     'slug' => 'bg',     'color' => '#FAFAF8' ),
    ) );

}
add_action( 'after_setup_theme', 'amnf_setup' );

// ─── Enqueue Scripts & Styles ─────────────────────────────────────────────────
function amnf_enqueue_assets() {
    $ver = '3.0.8';

    // Clean Editorial: Newsreader (serif headlines) + Inter (body/UI) + Devanagari support
    wp_enqueue_style(
        'amnf-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Newsreader:opsz,wght@6..72,400;6..72,600;6..72,700&family=Noto+Serif+Devanagari:wght@400;600;700&display=swap',
        array(),
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'amnf-style',
        get_template_directory_uri() . '/assets/css/main.css',
        array( 'amnf-google-fonts' ),
        $ver
    );

    // Theme stylesheet (WordPress requirement)
    wp_enqueue_style( 'amnf-theme', get_stylesheet_uri(), array(), $ver );

    // Main JS (deferred)
    wp_enqueue_script(
        'amnf-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        $ver,
        true   // load in footer
    );

    // Pass data to JS
    wp_localize_script( 'amnf-main', 'amnfData', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'amnf_nonce' ),
        'siteUrl' => get_site_url(),
    ) );

    // Comments reply script
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'amnf_enqueue_assets' );

// ─── Read Time Helper ─────────────────────────────────────────────────────────
function amnf_read_time( $post_id = null ) {
    $content    = get_post_field( 'post_content', $post_id );
    $word_count = str_word_count( wp_strip_all_tags( $content ) );
    $minutes    = max( 1, (int) ceil( $word_count / 200 ) );
    /* translators: %d: number of minutes */
    return sprintf( _n( '%d min read', '%d min read', $minutes, 'automotonews-future' ), $minutes );
}

// ─── Excerpt Length ───────────────────────────────────────────────────────────
function amnf_excerpt_length() { return 22; }
add_filter( 'excerpt_length', 'amnf_excerpt_length' );

function amnf_excerpt_more() { return '&hellip;'; }
add_filter( 'excerpt_more', 'amnf_excerpt_more' );

// Remove ALL auto-generated "Read more" / "Continue reading" links
function amnf_remove_more_link( $content ) {
    // Remove links with class "more-link"
    $content = preg_replace( '/<a[^>]*class=["\'][^"\']*more-link[^"\']*["\'][^>]*>.*?<\/a>/is', '', $content );
    // Remove standalone "Read more" links (no class)
    $content = preg_replace( '/<a[^>]*>\s*(Read more|Continue reading|&hellip;)\s*<\/a>/is', '', $content );
    // Remove <p> tags containing only a Read more link
    $content = preg_replace( '/<p[^>]*>\s*<a[^>]*>\s*(Read more|Continue reading)[^<]*<\/a>\s*<\/p>/is', '', $content );
    return $content;
}
add_filter( 'the_excerpt', 'amnf_remove_more_link', 999 );
add_filter( 'get_the_excerpt', 'amnf_remove_more_link', 999 );
add_filter( 'the_content', 'amnf_remove_more_link', 999 );

// Disable the <!--more--> "Read more" link entirely
function amnf_remove_content_more_link( $link ) { return ''; }
add_filter( 'the_content_more_link', 'amnf_remove_content_more_link', 999 );

// ─── Sidebar ──────────────────────────────────────────────────────────────────
function amnf_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'automotonews-future' ),
        'id'            => 'sidebar-main',
        'description'   => __( 'Widgets in this area appear on posts and pages.', 'automotonews-future' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s glass">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'amnf_widgets_init' );

// ─── Preconnect for Google Fonts ──────────────────────────────────────────────
function amnf_preconnect_fonts( $hints, $relation ) {
    if ( 'preconnect' === $relation ) {
        $hints[] = array( 'href' => 'https://fonts.googleapis.com' );
        $hints[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => true );
    }
    return $hints;
}
add_filter( 'wp_resource_hints', 'amnf_preconnect_fonts', 10, 2 );

// ─── Category URL Helper ──────────────────────────────────────────────────────
function amnf_get_category_url( $slug, $fallback = '' ) {
    $term = get_category_by_slug( $slug );
    if ( $term && ! is_wp_error( $term ) ) {
        return get_category_link( $term->term_id );
    }
    return $fallback ? $fallback : home_url( '/' );
}

// ─── Site Stats (real WordPress counts) ───────────────────────────────────────
function amnf_site_stats() {
    $counts    = wp_count_posts( 'post' );
    $published = isset( $counts->publish ) ? (int) $counts->publish : 0;
    $reviews   = amnf_count_category_posts( 'car-news' );
    if ( ! $reviews ) {
        $reviews = amnf_count_category_posts( 'reviews' );
    }

    return array(
        'articles' => max( $published, 1 ),
        'reviews'  => max( $reviews, min( $published, 50 ) ),
        'readers'  => max( (int) round( $published * 20 ), 100 ),
        'free'     => 100,
    );
}

function amnf_count_category_posts( $slug ) {
    $term = get_category_by_slug( $slug );
    if ( ! $term || is_wp_error( $term ) ) {
        return 0;
    }
    return (int) $term->count;
}

/**
 * Category IDs to exclude from non-EV sections (e.g. Bikes).
 */
function amnf_ev_category_ids() {
    $ids  = array();
    $slugs = array( 'electric-vehicles-evs', 'ev-news', 'daily-update' );
    foreach ( $slugs as $slug ) {
        $term = get_category_by_slug( $slug );
        if ( $term && ! is_wp_error( $term ) ) {
            $ids[] = (int) $term->term_id;
        }
    }
    return array_unique( $ids );
}

/**
 * Hide plugin-injected floating social (GeneratePress Element in wp_footer).
 * Inline plugin CSS loads after theme CSS; this runs last.
 */
function amnf_hide_floating_social_widgets() {
    echo '<style id="amnf-hide-floating-social">.amn-floating-social,.social-bar{display:none!important;visibility:hidden!important;pointer-events:none!important;height:0!important;width:0!important;overflow:hidden!important;opacity:0!important;}</style>';
}
add_action( 'wp_footer', 'amnf_hide_floating_social_widgets', 9999 );

function amnf_featured_hero_image() {
    $default = get_template_directory_uri() . '/assets/hero-dashboard.jpg';
    $featured = get_posts( array(
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'meta_key'       => '_thumbnail_id',
    ) );
    if ( $featured && has_post_thumbnail( $featured[0]->ID ) ) {
        $thumb = get_the_post_thumbnail_url( $featured[0]->ID, 'amnf-wide' );
        if ( $thumb ) {
            return $thumb;
        }
    }
    return $default;
}

/**
 * Header hero banner image (theme asset — replace assets/hero-dashboard.jpg to customize).
 */
function amnf_header_banner_url() {
    $url = get_template_directory_uri() . '/assets/hero-dashboard.jpg';
    return apply_filters( 'amnf_header_banner_url', $url );
}

/**
 * Resolve a published page URL by slug (first match wins).
 */
function amnf_page_url( $slugs, $fallback = '' ) {
    foreach ( (array) $slugs as $slug ) {
        $page = get_page_by_path( $slug );
        if ( $page && 'publish' === get_post_status( $page ) ) {
            return get_permalink( $page );
        }
    }
    return $fallback ? $fallback : home_url( '/' );
}

/**
 * Organization logo URL for schema (custom logo or theme fallback).
 */
function amnf_organization_logo_url() {
    $logo_id = get_theme_mod( 'custom_logo' );
    if ( $logo_id ) {
        $src = wp_get_attachment_image_url( $logo_id, 'full' );
        if ( $src ) {
            return $src;
        }
    }
    return get_template_directory_uri() . '/assets/hero-dashboard.jpg';
}

/**
 * AdSense-ready slot — paste code via hook `amnf_ad_slot_{location}` or Ad Inserter plugin targeting `.amnf-ad-slot`.
 */
function amnf_ad_slot( $location ) {
    if ( ! apply_filters( 'amnf_show_ad_slot', true, $location ) ) {
        return;
    }
    printf(
        '<aside class="amnf-ad-slot amnf-ad-slot--%1$s" id="amnf-ad-%1$s" aria-label="%2$s">',
        esc_attr( $location ),
        esc_attr__( 'Advertisement', 'automotonews-future' )
    );
    do_action( 'amnf_ad_slot_' . $location );
    echo '</aside>';
}

/**
 * Cookie consent banner (AdSense / GDPR).
 */
function amnf_cookie_consent_banner() {
    if ( is_admin() ) {
        return;
    }
    ?>
    <div id="amnf-cookie-consent" class="amnf-cookie-consent" role="dialog" aria-live="polite" aria-label="<?php esc_attr_e( 'Cookie consent', 'automotonews-future' ); ?>" hidden>
        <div class="amnf-cookie-inner site-shell">
            <p><?php
                printf(
                    wp_kses(
                        __( 'We use cookies for analytics and advertising (including Google AdSense). See our <a href="%s">Privacy Policy</a>.', 'automotonews-future' ),
                        array( 'a' => array( 'href' => array() ) )
                    ),
                    esc_url( amnf_page_url( array( 'privacy-policy' ), home_url( '/privacy-policy/' ) ) )
                );
            ?></p>
            <button type="button" class="btn btn-primary" id="amnf-cookie-accept"><?php esc_html_e( 'Accept', 'automotonews-future' ); ?></button>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'amnf_cookie_consent_banner', 5 );

/**
 * Footer social profiles (filterable).
 */
function amnf_footer_social_links() {
    $links = array(
        'instagram' => array(
            'url'   => 'https://www.instagram.com/automotonews.in/',
            'label' => __( 'Instagram', 'automotonews-future' ),
            'aria'  => __( 'Follow on Instagram', 'automotonews-future' ),
        ),
        'facebook'  => array(
            'url'   => 'https://www.facebook.com/automotonews.in',
            'label' => __( 'Facebook', 'automotonews-future' ),
            'aria'  => __( 'Follow on Facebook', 'automotonews-future' ),
        ),
        'youtube'   => array(
            'url'   => 'https://www.youtube.com/@automotonews',
            'label' => __( 'YouTube', 'automotonews-future' ),
            'aria'  => __( 'Subscribe on YouTube', 'automotonews-future' ),
        ),
        'whatsapp'  => array(
            'url'   => 'https://wa.me/919876543210',
            'label' => __( 'WhatsApp', 'automotonews-future' ),
            'aria'  => __( 'Chat on WhatsApp', 'automotonews-future' ),
        ),
        'telegram'  => array(
            'url'   => 'https://t.me/automotonews',
            'label' => __( 'Telegram', 'automotonews-future' ),
            'aria'  => __( 'Join Telegram channel', 'automotonews-future' ),
        ),
    );
    return apply_filters( 'amnf_footer_social_links', $links );
}

/**
 * Inline SVG icon for a social network key.
 */
function amnf_social_icon_svg( $network ) {
    $icons = array(
        'instagram' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor" stroke="none"/></svg>',
        'facebook'  => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M24 12.07C24 5.41 18.63 0 12 0S0 5.41 0 12.07c0 6.02 4.39 11.02 10.13 11.93v-8.4H7.08v-3.53h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.68.24 2.68.24v2.95h-1.51c-1.49 0-1.95.93-1.95 1.89v2.27h3.32l-.53 3.53h-2.79v8.4C19.61 23.09 24 18.09 24 12.07z"/></svg>',
        'youtube'   => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23.5 6.2a3.01 3.01 0 0 0-2.12-2.13C19.54 3.5 12 3.5 12 3.5s-7.54 0-9.38.47A3.01 3.01 0 0 0 .5 6.2 31.6 31.6 0 0 0 0 12a31.6 31.6 0 0 0 .5 5.8 3.01 3.01 0 0 0 2.12 2.13c1.84.47 9.38.47 9.38.47s7.54 0 9.38-.47a3.01 3.01 0 0 0 2.12-2.13A31.6 31.6 0 0 0 24 12a31.6 31.6 0 0 0-.5-5.8zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>',
        'whatsapp'  => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg>',
        'telegram'  => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.461-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',
    );
    return isset( $icons[ $network ] ) ? $icons[ $network ] : '';
}
