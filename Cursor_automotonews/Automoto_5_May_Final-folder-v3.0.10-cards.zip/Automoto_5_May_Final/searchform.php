<?php
/**
 * Custom search form
 * @package AutoMotoNews_Future
 */
$unique_id = esc_attr( uniqid( 'search-form-' ) );
?>
<form role="search" method="get" class="header-search search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
  <label class="screen-reader-text" for="<?php echo $unique_id; ?>"><?php esc_html_e( 'Search for:', 'automotonews-future' ); ?></label>
  <input type="search" id="<?php echo $unique_id; ?>" class="search-field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search cars, bikes, EVs…', 'automotonews-future' ); ?>" required>
  <button type="submit" class="search-submit" aria-label="<?php esc_attr_e( 'Submit search', 'automotonews-future' ); ?>">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
  </button>
</form>
