<?php
/**
 * 404 Not Found
 *
 * @package AutoMotoNews_Future
 */
get_header();
$explore = amnf_footer_explore_links();
?>
<main id="main-content" role="main" class="site-shell section">
    <div class="error-404 not-found">
        <h1><?php esc_html_e( 'Page not found', 'automotonews-future' ); ?></h1>
        <p><?php esc_html_e( 'The page you are looking for may have moved or no longer exists.', 'automotonews-future' ); ?></p>
        <?php get_search_form(); ?>
        <p class="error-404-links">
            <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to homepage', 'automotonews-future' ); ?></a>
        </p>

        <?php if ( ! empty( $explore ) ) : ?>
        <nav class="error-404-explore" aria-label="<?php esc_attr_e( 'Browse categories', 'automotonews-future' ); ?>">
            <h2><?php esc_html_e( 'Browse popular sections', 'automotonews-future' ); ?></h2>
            <ul class="error-404-categories">
                <?php foreach ( $explore as $link ) : ?>
                <li><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
