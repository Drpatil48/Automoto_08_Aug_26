<?php
/**
 * Index / Blog Archive Template
 * @package AutoMotoNews_Future
 */
get_header(); ?>

<main id="main-content" role="main" class="site-shell archive-main">

  <header class="archive-header">
    <h1><?php
      if ( is_category() )      single_cat_title();
      elseif ( is_tag() )       single_tag_title();
      elseif ( is_search() )    printf( esc_html__( 'Search results for: %s', 'automotonews-future' ), '<em>' . get_search_query() . '</em>' );
      elseif ( is_archive() )   the_archive_title();
      else                      esc_html_e( 'Latest News', 'automotonews-future' );
    ?></h1>
    <?php if ( is_category() && category_description() ) : ?>
      <p class="archive-description"><?php echo wp_kses_post( category_description() ); ?></p>
    <?php endif; ?>
  </header>

  <?php if ( have_posts() ) : ?>
  <div class="card-grid three" role="list">
    <?php while ( have_posts() ) : the_post();
      $cat      = get_the_category();
      $cat_name = $cat ? esc_html( $cat[0]->name ) : '';
      $cat_url  = $cat ? esc_url( get_category_link( $cat[0]->term_id ) ) : '#';
      $read_time = amnf_read_time( get_the_ID() );
    ?>
    <article class="news-card glass" role="listitem">
      <a href="<?php the_permalink(); ?>" class="card-img-link" tabindex="-1" aria-hidden="true">
        <?php if ( has_post_thumbnail() ) :
          the_post_thumbnail( 'amnf-card', array( 'alt' => get_the_title(), 'loading' => 'lazy', 'class' => 'card-img' ) );
        else : ?>
          <div class="card-img-placeholder" aria-hidden="true"></div>
        <?php endif; ?>
      </a>
      <div class="card-body">
        <?php if ( $cat_name ) : ?>
          <a href="<?php echo $cat_url; ?>" class="cat-badge"><?php echo $cat_name; ?></a>
        <?php endif; ?>
        <h2 class="card-title">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <p class="card-excerpt"><?php the_excerpt(); ?></p>
        <a href="<?php the_permalink(); ?>" class="btn-read-more" aria-label="<?php printf( esc_attr__( 'Read more about %s', 'automotonews-future' ), get_the_title() ); ?>"><?php esc_html_e( 'Read more', 'automotonews-future' ); ?></a>
        <div class="card-meta">
          <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo get_the_date( 'M j, Y' ); ?></time>
          <span class="read-time"><?php echo esc_html( $read_time ); ?></span>
        </div>
      </div>
    </article>
    <?php endwhile; ?>
  </div>

  <!-- Pagination -->
  <nav class="pagination-wrap" aria-label="<?php esc_attr_e( 'Posts pagination', 'automotonews-future' ); ?>">
    <?php the_posts_pagination( array(
        'mid_size'           => 2,
        'prev_text'          => '&larr; ' . __( 'Previous', 'automotonews-future' ),
        'next_text'          => __( 'Next', 'automotonews-future' ) . ' &rarr;',
        'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'automotonews-future' ) . ' </span>',
    ) ); ?>
  </nav>

  <?php else : ?>
  <div class="no-posts glass">
    <h2><?php esc_html_e( 'No posts found', 'automotonews-future' ); ?></h2>
    <p><?php esc_html_e( 'Try searching for something else or browse our categories.', 'automotonews-future' ); ?></p>
    <?php get_search_form(); ?>
  </div>
  <?php endif; ?>

</main>

<?php get_footer(); ?>
