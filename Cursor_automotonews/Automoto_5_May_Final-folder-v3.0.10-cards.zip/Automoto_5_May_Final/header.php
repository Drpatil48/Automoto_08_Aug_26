<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Dark mode: apply saved preference BEFORE page renders (prevents white flash) -->
<script>
(function(){
  try {
    if (localStorage.getItem('amnf-dark-mode') === 'enabled') {
      document.documentElement.classList.add('dark-mode-loading');
    }
  } catch(e) {}
})();
</script>
<style>
  /* Prevent flash: apply dark bg immediately if dark mode was saved */
  html.dark-mode-loading body,
  html.dark-mode-loading { background: #0f0f0f !important; }
</style>

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Skip to main content (accessibility + Core Web Vitals) -->
<a class="skip-link screen-reader-text" href="#main-content"><?php esc_html_e( 'Skip to main content', 'automotonews-future' ); ?></a>

<!-- Site Header -->
<header class="site-header" role="banner">
    <div class="header-top-band">
        <a class="header-hero-visual" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"
           aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — <?php echo esc_attr( get_bloginfo( 'description' ) ); ?>"
           style="--header-banner: url('<?php echo esc_url( amnf_header_banner_url() ); ?>');">
            <span class="header-hero-overlay" aria-hidden="true"></span>
            <span class="header-hero-streaks" aria-hidden="true"></span>
            <span class="header-hero-hex" aria-hidden="true"></span>
            <span class="header-hero-brand">
                <?php if ( has_custom_logo() ) : ?>
                    <?php
                    $logo_id = get_theme_mod( 'custom_logo' );
                    echo wp_get_attachment_image( $logo_id, 'medium', false, array(
                        'class'   => 'header-hero-logo',
                        'alt'     => get_bloginfo( 'name' ),
                        'loading' => 'eager',
                    ) );
                    ?>
                <?php else : ?>
                    <span class="header-hero-badge" aria-hidden="true">
                        <svg viewBox="0 0 40 40" width="28" height="28" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="20" cy="20" r="17" stroke="#fff" stroke-width="2.5"/>
                            <line x1="20" y1="20" x2="28" y2="12" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                            <circle cx="20" cy="20" r="3" fill="#fff"/>
                        </svg>
                    </span>
                    <span class="header-hero-name"><?php bloginfo( 'name' ); ?></span>
                <?php endif; ?>
            </span>
        </a>

        <div class="header-actions-panel">
            <form class="header-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Site search', 'automotonews-future' ); ?>">
                <label class="screen-reader-text" for="header-search-input"><?php esc_html_e( 'Search', 'automotonews-future' ); ?></label>
                <input type="search" id="header-search-input" name="s" placeholder="<?php esc_attr_e( 'Search cars, bikes, EV', 'automotonews-future' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" autocomplete="off" required>
                <button type="submit" aria-label="<?php esc_attr_e( 'Submit search', 'automotonews-future' ); ?>">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
                </button>
            </form>

            <button class="dark-mode-toggle" id="dark-mode-toggle" type="button" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'automotonews-future' ); ?>">
                <span class="icon-moon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"/>
                    </svg>
                </span>
                <span class="icon-sun" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="5"/>
                        <line x1="12" y1="1" x2="12" y2="3"/>
                        <line x1="12" y1="21" x2="12" y2="23"/>
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                        <line x1="1" y1="12" x2="3" y2="12"/>
                        <line x1="21" y1="12" x2="23" y2="12"/>
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
                    </svg>
                </span>
            </button>

            <button class="menu-toggle" id="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation" aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'automotonews-future' ); ?>">
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
            </button>
        </div>
    </div>

    <!-- Main category navigation -->
    <div class="secondary-nav-bar" id="secondary-nav-bar">
        <div class="site-shell">
            <nav id="primary-navigation" aria-label="<?php esc_attr_e( 'Main Navigation', 'automotonews-future' ); ?>">
                <?php
                if ( has_nav_menu( 'primary' ) ) {
                    wp_nav_menu( array(
                        'theme_location' => 'primary',
                        'menu_class'     => 'nav-menu horizontal-menu',
                        'container'      => false,
                        'depth'          => 2,
                        'fallback_cb'    => false,
                    ) );
                } else {
                    // Fallback default links
                    $nav_items = array(
                        __( 'Home', 'automotonews-future' )                    => home_url( '/' ),
                        __( 'Electric Vehicles EVs', 'automotonews-future' )   => amnf_get_category_url( 'electric-vehicles-evs', home_url( '/category/electric-vehicles-evs/' ) ),
                        __( 'Daily Update', 'automotonews-future' )            => amnf_get_category_url( 'daily-update', home_url( '/category/daily-update/' ) ),
                        __( 'Car News', 'automotonews-future' )                => amnf_get_category_url( 'car-news', home_url( '/category/car-news/' ) ),
                        __( 'Sports Bikes', 'automotonews-future' )            => amnf_get_category_url( 'sports-bikes', home_url( '/category/sports-bikes/' ) ),
                        __( 'Upcoming Cars', 'automotonews-future' )           => amnf_get_category_url( 'upcoming-cars', home_url( '/category/upcoming-cars/' ) ),
                    );
                    echo '<ul class="nav-menu horizontal-menu">';
                    foreach ( $nav_items as $label => $url ) {
                        $current = is_front_page() && $url === home_url( '/' ) ? ' current-menu-item' : '';
                        printf( '<li class="%s"><a href="%s">%s</a></li>', esc_attr( $current ), esc_url( $url ), esc_html( $label ) );
                    }
                    echo '</ul>';
                }
                ?>
            </nav>
            <form class="mobile-nav-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Mobile site search', 'automotonews-future' ); ?>">
                <label class="screen-reader-text" for="mobile-search-input"><?php esc_html_e( 'Search', 'automotonews-future' ); ?></label>
                <input type="search" id="mobile-search-input" name="s" placeholder="<?php esc_attr_e( 'Search…', 'automotonews-future' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>">
                <button type="submit" class="btn btn-primary"><?php esc_html_e( 'Search', 'automotonews-future' ); ?></button>
            </form>
        </div>
    </div>
</header>
