<?php
/**
 * Theme SEO helpers — defers to Rank Math / Yoast when active.
 *
 * @package AutoMotoNews_Future
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Detect major SEO plugins so theme meta/schema does not duplicate output.
 */
function amnf_seo_plugin_active() {
    return defined( 'RANK_MATH_VERSION' )
        || defined( 'WPSEO_VERSION' )
        || defined( 'AIOSEO_VERSION' )
        || class_exists( 'RankMath\\Helper', false )
        || function_exists( 'rank_math' );
}

/**
 * Whether theme should output JSON-LD (never when an SEO plugin is active).
 */
function amnf_theme_outputs_schema() {
    return ! amnf_seo_plugin_active() && apply_filters( 'amnf_theme_outputs_schema', true );
}

/**
 * Whether theme should output meta description / OG / canonical.
 */
function amnf_theme_outputs_meta() {
    return ! amnf_seo_plugin_active() && apply_filters( 'amnf_theme_outputs_meta', true );
}

/**
 * Build meta description for current query.
 */
function amnf_get_meta_description() {
    $description = '';

    if ( is_singular() ) {
        $post_id = get_queried_object_id();
        if ( has_excerpt( $post_id ) ) {
            $description = wp_strip_all_tags( get_the_excerpt( $post_id ) );
        } else {
            $description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30 );
        }
    } elseif ( is_category() || is_tag() || is_tax() ) {
        $description = term_description();
        if ( ! $description ) {
            $description = single_term_title( '', false ) . ' — ' . get_bloginfo( 'description' );
        }
    } elseif ( is_author() ) {
        $description = get_the_author_meta( 'description', get_queried_object_id() );
    } elseif ( is_search() ) {
        /* translators: %s: search query */
        $description = sprintf( __( 'Search results for "%s" on %s.', 'automotonews-future' ), get_search_query(), get_bloginfo( 'name' ) );
    } elseif ( is_home() || is_front_page() ) {
        $description = get_bloginfo( 'description' );
    }

    if ( empty( $description ) ) {
        $description = get_bloginfo( 'description' );
    }

    return wp_strip_all_tags( $description );
}

/**
 * Canonical URL for current query.
 */
function amnf_get_canonical_url() {
    if ( is_singular() ) {
        return get_permalink();
    }
    if ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && ! is_wp_error( $term ) ) {
            return get_term_link( $term );
        }
    }
    if ( is_author() ) {
        return get_author_posts_url( get_queried_object_id() );
    }
    if ( is_search() ) {
        return get_search_link( get_search_query() );
    }
    if ( is_post_type_archive() ) {
        return get_post_type_archive_link( get_post_type() );
    }
    return home_url( '/' );
}

/**
 * OG image for current query.
 */
function amnf_get_og_image() {
    if ( is_singular() && has_post_thumbnail() ) {
        $url = get_the_post_thumbnail_url( null, 'large' );
        if ( $url ) {
            return $url;
        }
    }
    return amnf_organization_logo_url();
}

/**
 * OG title for current query.
 */
function amnf_get_og_title() {
    if ( is_singular() ) {
        return get_the_title() . ' – ' . get_bloginfo( 'name' );
    }
    if ( is_category() || is_tag() || is_tax() ) {
        return single_term_title( '', false ) . ' | ' . get_bloginfo( 'name' );
    }
    if ( is_search() ) {
        return sprintf( __( 'Search: %s', 'automotonews-future' ), get_search_query() ) . ' | ' . get_bloginfo( 'name' );
    }
    return get_bloginfo( 'name' );
}

/**
 * Theme meta tags (only when no SEO plugin).
 */
function amnf_output_theme_meta_tags() {
    if ( ! amnf_theme_outputs_meta() ) {
        return;
    }

    $description = esc_attr( amnf_get_meta_description() );
    $og_title    = esc_attr( amnf_get_og_title() );
    $og_url      = esc_url( amnf_get_canonical_url() );
    $og_image    = esc_url( amnf_get_og_image() );
    $og_type     = is_singular( 'post' ) ? 'article' : 'website';
    $locale      = esc_attr( get_locale() );

    echo '<meta name="description" content="' . $description . '">' . "\n";
    echo '<link rel="canonical" href="' . $og_url . '">' . "\n";
    echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '">' . "\n";
    echo '<meta property="og:title" content="' . $og_title . '">' . "\n";
    echo '<meta property="og:description" content="' . $description . '">' . "\n";
    echo '<meta property="og:url" content="' . $og_url . '">' . "\n";
    echo '<meta property="og:image" content="' . $og_image . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
    echo '<meta property="og:locale" content="' . $locale . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<meta name="twitter:title" content="' . $og_title . '">' . "\n";
    echo '<meta name="twitter:description" content="' . $description . '">' . "\n";
    echo '<meta name="twitter:image" content="' . $og_image . '">' . "\n";
}
add_action( 'wp_head', 'amnf_output_theme_meta_tags', 1 );

/**
 * JSON-LD schema (only when no SEO plugin).
 */
function amnf_output_theme_schema() {
    if ( ! amnf_theme_outputs_schema() ) {
        return;
    }

    $site_name = get_bloginfo( 'name' );
    $site_desc = get_bloginfo( 'description' );
    $site_url  = home_url( '/' );
    $logo_url  = amnf_organization_logo_url();

    $graph = array();

    $graph[] = array(
        '@type'       => 'Organization',
        '@id'         => $site_url . '#organization',
        'name'        => $site_name,
        'url'         => $site_url,
        'logo'        => array(
            '@type' => 'ImageObject',
            'url'   => $logo_url,
        ),
        'sameAs'      => array_values( array_filter( wp_list_pluck( amnf_footer_social_links(), 'url' ) ) ),
    );

    $graph[] = array(
        '@type'            => 'WebSite',
        '@id'              => $site_url . '#website',
        'url'              => $site_url,
        'name'             => $site_name,
        'description'      => $site_desc,
        'publisher'        => array( '@id' => $site_url . '#organization' ),
        'potentialAction'  => array(
            '@type'       => 'SearchAction',
            'target'      => array(
                '@type'       => 'EntryPoint',
                'urlTemplate' => home_url( '/?s={search_term_string}' ),
            ),
            'query-input' => 'required name=search_term_string',
        ),
    );

    if ( is_singular( 'post' ) ) {
        $post_id      = get_queried_object_id();
        $schema_image = has_post_thumbnail( $post_id ) ? get_the_post_thumbnail_url( $post_id, 'large' ) : $logo_url;
        $article      = array(
            '@type'            => 'NewsArticle',
            '@id'              => get_permalink( $post_id ) . '#article',
            'headline'         => get_the_title( $post_id ),
            'description'      => amnf_get_meta_description(),
            'image'            => array( $schema_image ),
            'datePublished'    => get_the_date( 'c', $post_id ),
            'dateModified'     => get_the_modified_date( 'c', $post_id ),
            'author'           => array(
                '@type' => 'Person',
                'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
            ),
            'publisher'        => array( '@id' => $site_url . '#organization' ),
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id'   => get_permalink( $post_id ),
            ),
            'isPartOf'         => array( '@id' => $site_url . '#website' ),
        );

        $cats = get_the_category( $post_id );
        if ( ! empty( $cats ) ) {
            $article['articleSection'] = $cats[0]->name;
        }

        $graph[] = $article;

        $breadcrumb = amnf_build_breadcrumb_schema( $post_id );
        if ( $breadcrumb ) {
            $graph[] = $breadcrumb;
        }
    } elseif ( is_page() ) {
        $post_id = get_queried_object_id();
        $graph[] = array(
            '@type'       => 'WebPage',
            '@id'         => get_permalink( $post_id ) . '#webpage',
            'url'         => get_permalink( $post_id ),
            'name'        => get_the_title( $post_id ),
            'description' => amnf_get_meta_description(),
            'isPartOf'    => array( '@id' => $site_url . '#website' ),
        );
        $breadcrumb = amnf_build_breadcrumb_schema( $post_id );
        if ( $breadcrumb ) {
            $graph[] = $breadcrumb;
        }
    } elseif ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && ! is_wp_error( $term ) ) {
            $graph[] = array(
                '@type'       => 'CollectionPage',
                '@id'         => get_term_link( $term ) . '#collection',
                'url'         => get_term_link( $term ),
                'name'        => single_term_title( '', false ),
                'description' => wp_strip_all_tags( term_description() ),
                'isPartOf'    => array( '@id' => $site_url . '#website' ),
            );
        }
    }

    $payload = array(
        '@context' => 'https://schema.org',
        '@graph'   => $graph,
    );

    echo '<script type="application/ld+json">' . wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'amnf_output_theme_schema', 2 );

/**
 * Build BreadcrumbList schema for posts/pages.
 */
function amnf_build_breadcrumb_schema( $post_id = null ) {
    $items   = array();
    $items[] = array(
        'name'     => __( 'Home', 'automotonews-future' ),
        'url'      => home_url( '/' ),
        'position' => 1,
    );

    $position = 2;

    if ( $post_id && 'post' === get_post_type( $post_id ) ) {
        $cats = get_the_category( $post_id );
        if ( ! empty( $cats ) ) {
            $items[] = array(
                'name'     => $cats[0]->name,
                'url'      => get_category_link( $cats[0]->term_id ),
                'position' => $position++,
            );
        }
    }

    $items[] = array(
        'name'     => get_the_title( $post_id ),
        'url'      => get_permalink( $post_id ),
        'position' => $position,
    );

    $list = array();
    foreach ( $items as $item ) {
        $list[] = array(
            '@type'    => 'ListItem',
            'position' => $item['position'],
            'name'     => $item['name'],
            'item'     => $item['url'],
        );
    }

    return array(
        '@type'           => 'BreadcrumbList',
        '@id'             => get_permalink( $post_id ) . '#breadcrumb',
        'itemListElement' => $list,
    );
}

/**
 * noindex for search & 404 (fallback when SEO plugin absent).
 */
function amnf_robots_meta( $robots ) {
    if ( amnf_seo_plugin_active() ) {
        return $robots;
    }
    if ( is_search() || is_404() ) {
        $robots['noindex'] = true;
        $robots['follow']  = true;
    }
    return $robots;
}
add_filter( 'wp_robots', 'amnf_robots_meta' );

/**
 * rel prev/next for paginated archives.
 */
function amnf_rel_pagination_links() {
    global $wp_query;

    if ( ! is_archive() && ! is_home() && ! is_search() ) {
        return;
    }

    $paged = max( 1, (int) get_query_var( 'paged' ) );
    $max   = isset( $wp_query->max_num_pages ) ? (int) $wp_query->max_num_pages : 1;

    if ( $max < 2 ) {
        return;
    }

    if ( $paged > 1 ) {
        echo '<link rel="prev" href="' . esc_url( get_pagenum_link( $paged - 1 ) ) . '">' . "\n";
    }
    if ( $paged < $max ) {
        echo '<link rel="next" href="' . esc_url( get_pagenum_link( $paged + 1 ) ) . '">' . "\n";
    }
}
add_action( 'wp_head', 'amnf_rel_pagination_links', 3 );

/**
 * Preload LCP hero image on front page.
 */
function amnf_preload_lcp_image() {
    if ( ! is_front_page() ) {
        return;
    }
    $hero = amnf_header_banner_url();
    echo '<link rel="preload" as="image" href="' . esc_url( $hero ) . '" fetchpriority="high">' . "\n";
}
add_action( 'wp_head', 'amnf_preload_lcp_image', 1 );

/**
 * Non-blocking Google Fonts.
 */
function amnf_async_google_fonts( $html, $handle ) {
    if ( 'amnf-google-fonts' !== $handle ) {
        return $html;
    }
    $html = str_replace( "media='all'", "media='print' onload=\"this.media='all'\"", $html );
    $html = str_replace( 'media="all"', 'media="print" onload="this.media=\'all\'"', $html );
    return $html . '<noscript>' . str_replace( array( "media='print' onload=\"this.media='all'\"", 'media="print" onload="this.media=\'all\'"' ), array( "media='all'", 'media="all"' ), $html ) . '</noscript>';
}
add_filter( 'style_loader_tag', 'amnf_async_google_fonts', 10, 2 );

/**
 * Defer theme JS.
 */
function amnf_defer_theme_scripts( $tag, $handle ) {
    if ( 'amnf-main' === $handle && false === strpos( $tag, ' defer' ) ) {
        $tag = str_replace( ' src=', ' defer src=', $tag );
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'amnf_defer_theme_scripts', 10, 2 );

/**
 * Add alt text to content images missing alt (uses post title).
 */
function amnf_content_image_alt( $content ) {
    if ( ! is_singular() || empty( $content ) ) {
        return $content;
    }
    $title = get_the_title();
    return preg_replace_callback(
        '/<img(?![^>]*\balt=)([^>]*)>/i',
        function ( $matches ) use ( $title ) {
            return '<img alt="' . esc_attr( $title ) . '"' . $matches[1] . '>';
        },
        $content
    );
}
add_filter( 'the_content', 'amnf_content_image_alt', 12 );

/**
 * Related posts for internal linking (same category).
 */
function amnf_related_posts( $post_id = null, $count = 4 ) {
    $post_id = $post_id ? $post_id : get_the_ID();
    if ( ! $post_id ) {
        return;
    }

    $cats = wp_get_post_categories( $post_id );
    if ( empty( $cats ) ) {
        return;
    }

    $related = new WP_Query( array(
        'posts_per_page'      => $count,
        'post__not_in'        => array( $post_id ),
        'category__in'        => array( $cats[0] ),
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
    ) );

    if ( ! $related->have_posts() ) {
        return;
    }
    ?>
    <section class="related-posts" aria-labelledby="related-posts-heading">
        <h2 id="related-posts-heading"><?php esc_html_e( 'Related Articles', 'automotonews-future' ); ?></h2>
        <ul class="related-posts-list">
            <?php
            while ( $related->have_posts() ) :
                $related->the_post();
                ?>
                <li>
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time>
                </li>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>
        </ul>
    </section>
    <?php
}

/**
 * Footer explore links — internal linking to key categories.
 */
function amnf_footer_explore_links() {
    $slugs = array(
        'electric-vehicles-evs' => __( 'EV News', 'automotonews-future' ),
        'car-news'              => __( 'Car News', 'automotonews-future' ),
        'sports-bikes'          => __( 'Sports Bikes', 'automotonews-future' ),
        'upcoming-cars'         => __( 'Upcoming Cars', 'automotonews-future' ),
        'buying-guide'          => __( 'Buying Guides', 'automotonews-future' ),
    );
    $links = array();
    foreach ( $slugs as $slug => $label ) {
        $term = get_category_by_slug( $slug );
        if ( $term && ! is_wp_error( $term ) && $term->count > 0 ) {
            $links[] = array(
                'url'   => get_category_link( $term->term_id ),
                'label' => $label,
            );
        }
    }
    return apply_filters( 'amnf_footer_explore_links', $links );
}
