<?php
/**
 * Comments template
 *
 * @package AutoMotoNews_Future
 */

if ( post_password_required() ) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>
        <h2 class="comments-title">
            <?php
            $count = get_comments_number();
            if ( '1' === $count ) {
                esc_html_e( 'One comment', 'automotonews-future' );
            } else {
                printf( esc_html( _n( '%s comment', '%s comments', $count, 'automotonews-future' ) ), esc_html( number_format_i18n( $count ) ) );
            }
            ?>
        </h2>
        <ol class="comment-list">
            <?php
            wp_list_comments( array(
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 48,
            ) );
            ?>
        </ol>
        <?php the_comments_navigation(); ?>
    <?php endif; ?>

    <?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'automotonews-future' ); ?></p>
    <?php endif; ?>

    <?php
    comment_form( array(
        'title_reply'          => __( 'Leave a comment', 'automotonews-future' ),
        'label_submit'         => __( 'Post comment', 'automotonews-future' ),
        'comment_notes_before' => '<p class="comment-notes">' . esc_html__( 'Your email will not be published. Required fields are marked *', 'automotonews-future' ) . '</p>',
    ) );
    ?>
</div>
