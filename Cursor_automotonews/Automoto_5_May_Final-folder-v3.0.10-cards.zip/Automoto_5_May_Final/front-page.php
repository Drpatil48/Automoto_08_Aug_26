<?php
/**
 * Front Page Template — Clean Editorial
 * @package AutoMotoNews_Future
 * @version 3.0.0
 */

// Helper: render a post card with 16:9 thumbnail, meta, and link
function amnf_render_card( $post_id, $size = 'amnf-card', $class = 'news-card' ) {
    $title     = get_the_title( $post_id );
    $permalink = get_permalink( $post_id );
    $excerpt   = wp_trim_words( get_the_excerpt( $post_id ), 18, '&hellip;' );
    $date      = get_the_date( 'M j, Y', $post_id );
    $cat       = get_the_category( $post_id );
    $cat_name  = $cat ? esc_html( $cat[0]->name ) : '';
    $cat_url   = $cat ? esc_url( get_category_link( $cat[0]->term_id ) ) : '#';
    $read_time = amnf_read_time( $post_id );
    $is_ev     = $cat && ( false !== stripos( $cat[0]->slug, 'ev' ) || false !== stripos( $cat[0]->name, 'electric' ) );

    if ( has_post_thumbnail( $post_id ) ) {
        $thumb = get_the_post_thumbnail( $post_id, $size, array(
            'alt'     => esc_attr( $title ),
            'loading' => 'lazy',
            'class'   => 'card-img',
            'width'   => ( 'amnf-feature' === $size ) ? 760 : 640,
            'height'  => ( 'amnf-feature' === $size ) ? 430 : 360,
        ) );
    } else {
        $thumb = '<div class="card-img-placeholder" aria-hidden="true"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg></div>';
    }
    ?>
    <article class="<?php echo esc_attr( $class ); ?>">
        <a href="<?php echo esc_url( $permalink ); ?>" class="card-img-link" tabindex="-1" aria-hidden="true"><?php echo $thumb; ?></a>
        <div class="card-body">
            <?php if ( $cat_name ) : ?>
            <a href="<?php echo $cat_url; ?>" class="cat-label<?php echo $is_ev ? ' cat-label--ev' : ''; ?>" aria-label="<?php printf( esc_attr__( 'Category: %s', 'automotonews-future' ), $cat_name ); ?>"><?php echo $cat_name; ?></a>
            <?php endif; ?>
            <h3><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3>
            <?php if ( $excerpt ) : ?><p class="card-excerpt"><?php echo $excerpt; ?></p><?php endif; ?>
            <div class="card-meta">
                <time class="card-date" datetime="<?php echo esc_attr( get_the_date( 'c', $post_id ) ); ?>"><?php echo $date; ?></time>
                <span class="read-time" aria-label="<?php echo esc_attr( $read_time ); ?>"><?php echo esc_html( $read_time ); ?></span>
            </div>
            <a href="<?php echo esc_url( $permalink ); ?>" class="btn-read-more" aria-label="<?php printf( esc_attr__( 'Read more about %s', 'automotonews-future' ), $title ); ?>"><?php esc_html_e( 'Read more', 'automotonews-future' ); ?></a>
        </div>
    </article>
    <?php
}

get_header();

$amnf_stats = amnf_site_stats();

// Featured story (latest published)
$tl_title = __( 'Latest automotive news', 'automotonews-future' );
$tl_link  = home_url( '/' );
$tl_date  = '';
$hero_bg  = amnf_featured_hero_image();
$tl_q = new WP_Query( array( 'posts_per_page' => 1, 'post_status' => 'publish' ) );
if ( $tl_q->have_posts() ) {
    $tl_q->the_post();
    $tl_title = get_the_title();
    $tl_link  = get_permalink();
    $tl_date  = get_the_date( 'F j, Y' );
    if ( has_post_thumbnail() ) {
        $hero_bg = get_the_post_thumbnail_url( get_the_ID(), 'amnf-wide' );
    }
    wp_reset_postdata();
}
?>

<main id="main-content" role="main" class="site-shell">

  <h1 class="home-page-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> — <?php echo esc_html( get_bloginfo( 'description' ) ); ?></h1>

  <!-- ── Featured Story (hero) ──────────────────────────────────────────── -->
  <div class="tl-featured-card" aria-label="<?php esc_attr_e( 'Featured story', 'automotonews-future' ); ?>">
    <div class="tl-featured-bg" style="background-image:url('<?php echo esc_url( $hero_bg ); ?>');" aria-hidden="true">
      <div class="tl-featured-vignette" aria-hidden="true"></div>
    </div>
    <div class="tl-featured-content">
      <div class="tl-featured-meta">
        <span class="tl-tag"><?php esc_html_e( 'Featured Story', 'automotonews-future' ); ?></span>
        <?php if ( $tl_date ) : ?>
        <span class="tl-featured-date"><?php echo esc_html( $tl_date ); ?></span>
        <?php endif; ?>
      </div>
      <h2 class="tl-featured-title"><?php echo esc_html( $tl_title ); ?></h2>
      <a href="<?php echo esc_url( $tl_link ); ?>" class="tl-featured-cta" aria-label="<?php esc_attr_e( 'Read featured article', 'automotonews-future' ); ?>">
        <?php esc_html_e( 'Read Full Story', 'automotonews-future' ); ?>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </a>
    </div>
  </div>

  <!-- ── Site stats (real WP counts) ───────────────────────────────────── -->
  <div class="stats-bar" id="stats-bar" aria-label="<?php esc_attr_e( 'Site statistics', 'automotonews-future' ); ?>">
    <div class="stats-bar-inner">
      <div class="stat-item">
        <span class="stat-number" data-target="<?php echo esc_attr( $amnf_stats['articles'] ); ?>" data-suffix="+"><?php echo esc_html( $amnf_stats['articles'] ); ?>+</span>
        <span class="stat-label"><?php esc_html_e( 'Articles', 'automotonews-future' ); ?></span>
      </div>
      <div class="stat-divider" aria-hidden="true"></div>
      <div class="stat-item">
        <span class="stat-number" data-target="<?php echo esc_attr( (int) round( $amnf_stats['readers'] / 1000 ) ); ?>" data-suffix="K+"><?php echo esc_html( (int) round( $amnf_stats['readers'] / 1000 ) ); ?>K+</span>
        <span class="stat-label"><?php esc_html_e( 'Monthly Readers', 'automotonews-future' ); ?></span>
      </div>
      <div class="stat-divider" aria-hidden="true"></div>
      <div class="stat-item">
        <span class="stat-number" data-target="<?php echo esc_attr( $amnf_stats['reviews'] ); ?>" data-suffix="+"><?php echo esc_html( $amnf_stats['reviews'] ); ?>+</span>
        <span class="stat-label"><?php esc_html_e( 'Car Reviews', 'automotonews-future' ); ?></span>
      </div>
      <div class="stat-divider" aria-hidden="true"></div>
      <div class="stat-item">
        <span class="stat-number" data-target="100" data-suffix="%">100%</span>
        <span class="stat-label"><?php esc_html_e( 'Free Content', 'automotonews-future' ); ?></span>
      </div>
    </div>
  </div>

  <?php amnf_ad_slot( 'home_after_stats' ); ?>

  <!-- ── Top Stories ─────────────────────────────────────────────────── -->
  <section id="top-stories" class="section" aria-labelledby="top-stories-heading">
    <div class="section-heading">
      <h2 id="top-stories-heading"><?php esc_html_e( 'Top Stories', 'automotonews-future' ); ?></h2>
    </div>
    <ul class="top-stories-list editorial-story-list">
      <?php
      $hero_q = new WP_Query( array( 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'offset' => 1 ) );
      if ( $hero_q->have_posts() ) :
          while ( $hero_q->have_posts() ) : $hero_q->the_post();
              $story_cat = get_the_category();
              $story_cat_name = $story_cat ? esc_html( $story_cat[0]->name ) : '';
              ?>
          <li class="editorial-story-item">
            <a href="<?php the_permalink(); ?>" class="editorial-story-thumb" tabindex="-1" aria-hidden="true">
              <?php if ( has_post_thumbnail() ) :
                  the_post_thumbnail( 'amnf-story', array(
                      'alt'     => esc_attr( get_the_title() ),
                      'loading' => 'lazy',
                      'width'   => 120,
                      'height'  => 68,
                  ) );
              else : ?>
                <span class="story-thumb-placeholder" aria-hidden="true"></span>
              <?php endif; ?>
            </a>
            <div class="editorial-story-body">
              <?php if ( $story_cat_name ) : ?>
                <span class="cat-label"><?php echo $story_cat_name; ?></span>
              <?php endif; ?>
              <a class="editorial-story-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
              <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time>
            </div>
          </li>
          <?php endwhile; wp_reset_postdata();
      else : ?>
          <li><?php esc_html_e( 'Publish your first post to see top stories.', 'automotonews-future' ); ?></li>
      <?php endif; ?>
    </ul>
  </section>

  <!-- ── EV Spotlight ────────────────────────────────────────────────── -->
  <section id="ev" class="section" aria-labelledby="ev-heading">
    <div class="section-heading">
      <h2 id="ev-heading"><?php esc_html_e( 'EV Spotlight', 'automotonews-future' ); ?></h2>
      <p><?php esc_html_e( 'Charging, battery health, range, and the latest EV launches.', 'automotonews-future' ); ?></p>
    </div>
    <div class="card-grid three">
      <?php
      $ev_q = new WP_Query( array( 'posts_per_page' => 3, 'category_name' => 'electric-vehicles-evs' ) );
      if ( ! $ev_q->have_posts() ) {
          $ev_q = new WP_Query( array( 'posts_per_page' => 3, 'category_name' => 'ev-news' ) );
      }
      if ( $ev_q->have_posts() ) :
          while ( $ev_q->have_posts() ) : $ev_q->the_post(); amnf_render_card( get_the_ID() ); endwhile;
          wp_reset_postdata();
      else :
          $latest_q = new WP_Query( array( 'posts_per_page' => 3 ) );
          if ( $latest_q->have_posts() ) :
              while ( $latest_q->have_posts() ) : $latest_q->the_post(); amnf_render_card( get_the_ID() ); endwhile;
              wp_reset_postdata();
          endif;
      endif; ?>
    </div>
  </section>

  <!-- ── Bikes & Performance ─────────────────────────────────────────── -->
  <section id="bikes" class="section" aria-labelledby="bikes-heading">
    <div class="section-heading">
      <h2 id="bikes-heading"><?php esc_html_e( 'Bikes &amp; Performance', 'automotonews-future' ); ?></h2>
      <p><?php esc_html_e( 'Commuter, sport, and electric two-wheelers with practical ownership insights.', 'automotonews-future' ); ?></p>
    </div>
    <div class="card-grid three">
      <?php
      $exclude_ev = amnf_ev_category_ids();
      $bike_args  = array( 'posts_per_page' => 3, 'category_name' => 'sports-bikes' );
      if ( $exclude_ev ) {
          $bike_args['category__not_in'] = $exclude_ev;
      }
      $bike_q = new WP_Query( $bike_args );
      if ( ! $bike_q->have_posts() ) {
          $bike_args['category_name'] = 'bike-news';
          $bike_q = new WP_Query( $bike_args );
      }
      if ( $bike_q->have_posts() ) :
          while ( $bike_q->have_posts() ) : $bike_q->the_post(); amnf_render_card( get_the_ID() ); endwhile;
          wp_reset_postdata();
      else :
          $latest_q3 = new WP_Query( array(
              'posts_per_page' => 3,
              'offset'         => 6,
              'category__not_in' => $exclude_ev,
          ) );
          if ( $latest_q3->have_posts() ) :
              while ( $latest_q3->have_posts() ) : $latest_q3->the_post(); amnf_render_card( get_the_ID() ); endwhile;
              wp_reset_postdata();
          endif;
      endif; ?>
    </div>
  </section>

  <!-- ── Compare Before You Buy ──────────────────────────────────────── -->
  <section id="compare" class="section" aria-labelledby="compare-heading">
    <div class="section-heading">
      <h2 id="compare-heading"><?php esc_html_e( 'Compare Before You Buy', 'automotonews-future' ); ?></h2>
      <p><?php esc_html_e( 'Select two models and check price, range, and key specs side by side.', 'automotonews-future' ); ?></p>
    </div>
    <div class="compare-tool">
      <div class="compare-controls">
        <div class="compare-group">
          <label for="modelA"><?php esc_html_e( 'Model A', 'automotonews-future' ); ?></label>
          <select id="modelA" name="modelA" aria-label="<?php esc_attr_e( 'Select first vehicle', 'automotonews-future' ); ?>"></select>
        </div>
        <span class="compare-vs" aria-hidden="true"><?php esc_html_e( 'vs', 'automotonews-future' ); ?></span>
        <div class="compare-group">
          <label for="modelB"><?php esc_html_e( 'Model B', 'automotonews-future' ); ?></label>
          <select id="modelB" name="modelB" aria-label="<?php esc_attr_e( 'Select second vehicle', 'automotonews-future' ); ?>"></select>
        </div>
        <button id="compareButton" class="btn btn-primary compare-submit" type="button"><?php esc_html_e( 'Compare', 'automotonews-future' ); ?></button>
      </div>
      <div id="compareResult" class="compare-result compare-result--loading" role="region" aria-live="polite" aria-busy="true" aria-label="<?php esc_attr_e( 'Comparison results', 'automotonews-future' ); ?>"></div>
    </div>
  </section>

  <!-- ── Latest Guides ───────────────────────────────────────────────── -->
  <section id="guides" class="section" aria-labelledby="guides-heading">
    <div class="section-heading">
      <h2 id="guides-heading"><?php esc_html_e( 'Latest Guides', 'automotonews-future' ); ?></h2>
      <p><?php esc_html_e( 'Actionable recommendations by budget and use case.', 'automotonews-future' ); ?></p>
    </div>
    <div class="card-grid four guide-grid">
      <?php
      $guide_q = new WP_Query( array( 'posts_per_page' => 4, 'category_name' => 'buying-guide' ) );
      if ( $guide_q->have_posts() ) :
          while ( $guide_q->have_posts() ) : $guide_q->the_post(); ?>
          <article class="guide-card">
            <?php if ( has_post_thumbnail() ) : ?>
              <a href="<?php the_permalink(); ?>" class="guide-card-img" tabindex="-1" aria-hidden="true">
                <?php the_post_thumbnail( 'amnf-mini', array( 'alt' => get_the_title(), 'loading' => 'lazy', 'width' => 320, 'height' => 180 ) ); ?>
              </a>
            <?php endif; ?>
            <div class="card-body">
              <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <p class="guide-desc"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 12, '&hellip;' ) ); ?></p>
            </div>
          </article>
          <?php endwhile; wp_reset_postdata();
      else :
          $guide_items = array(
              array(
                  'Best EV Under 15L',
                  __( 'Budget electric cars worth considering in India.', 'automotonews-future' ),
                  amnf_get_category_url( 'electric-vehicles-evs', home_url( '/category/electric-vehicles-evs/' ) ),
              ),
              array(
                  'Top Family SUV Picks',
                  __( 'Space, safety, and value for family buyers.', 'automotonews-future' ),
                  amnf_get_category_url( 'car-news', home_url( '/category/car-news/' ) ),
              ),
              array(
                  'Mileage Kings',
                  __( 'High-efficiency cars and bikes for daily commute.', 'automotonews-future' ),
                  amnf_get_category_url( 'daily-update', home_url( '/category/daily-update/' ) ),
              ),
              array(
                  'Best City Bikes',
                  __( 'Reliable two-wheelers for Indian city traffic.', 'automotonews-future' ),
                  amnf_get_category_url( 'sports-bikes', home_url( '/category/sports-bikes/' ) ),
              ),
          );
          foreach ( $guide_items as $guide ) :
              $guide_mod = sanitize_title( $guide[0] );
              ?>
          <article class="guide-card guide-card--fallback">
            <a href="<?php echo esc_url( $guide[2] ); ?>" class="guide-card-img guide-card-img--placeholder guide-card-img--<?php echo esc_attr( $guide_mod ); ?>" tabindex="-1" aria-hidden="true">
              <span class="guide-card-placeholder-label"><?php echo esc_html( $guide[0] ); ?></span>
            </a>
            <div class="card-body">
              <h3><a href="<?php echo esc_url( $guide[2] ); ?>"><?php echo esc_html( $guide[0] ); ?></a></h3>
              <p class="guide-desc"><?php echo esc_html( $guide[1] ); ?></p>
            </div>
          </article>
          <?php endforeach;
      endif; ?>
    </div>
  </section>

</main>

<?php get_footer(); ?>
