<!-- Footer -->
<footer class="site-footer" role="contentinfo">
    <div class="site-shell footer-inner">

        <!-- Footer Brand -->
        <div class="footer-brand">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand footer-brand-link" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> Homepage">
                <span class="brand-badge" aria-hidden="true">
                  <svg viewBox="0 0 40 40" width="30" height="30" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="20" r="17" stroke="#fff" stroke-width="2.5"/>
                    <circle cx="20" cy="20" r="13" stroke="#fff" stroke-width="1.2" stroke-dasharray="3 3"/>
                    <line x1="20" y1="20" x2="28" y2="12" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                    <circle cx="20" cy="20" r="3" fill="#fff"/>
                    <line x1="7" y1="20" x2="10" y2="20" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>
                    <line x1="20" y1="7" x2="20" y2="10" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>
                    <line x1="33" y1="20" x2="30" y2="20" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                </span>
                <span class="brand-name"><?php bloginfo( 'name' ); ?></span>
            </a>
            <p class="footer-tagline"><?php bloginfo( 'description' ); ?></p>

            <!-- Footer Nav -->
            <nav class="footer-nav" aria-label="<?php esc_attr_e( 'Footer Navigation', 'automotonews-future' ); ?>">
                <?php
                if ( has_nav_menu( 'footer' ) ) {
                    wp_nav_menu( array(
                        'theme_location' => 'footer',
                        'container'      => false,
                        'menu_class'     => 'footer-nav-list',
                        'depth'          => 1,
                        'fallback_cb'    => false,
                    ) );
                } else {
                    $footer_links = array(
                        __( 'About Us', 'automotonews-future' )      => amnf_page_url( array( 'about-us', 'about' ), home_url( '/about/' ) ),
                        __( 'Privacy Policy', 'automotonews-future' ) => amnf_page_url( array( 'privacy-policy' ), home_url( '/privacy-policy/' ) ),
                        __( 'Disclaimer', 'automotonews-future' )    => amnf_page_url( array( 'disclaimer' ), home_url( '/disclaimer/' ) ),
                        __( 'Contact', 'automotonews-future' )       => amnf_page_url( array( 'contact' ), home_url( '/contact/' ) ),
                    );
                    echo '<ul class="footer-nav-list">';
                    foreach ( $footer_links as $label => $url ) {
                        printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
                    }
                    echo '</ul>';
                }
                ?>
            </nav>

            <?php
            $explore_links = amnf_footer_explore_links();
            if ( ! empty( $explore_links ) ) :
            ?>
            <nav class="footer-explore" aria-label="<?php esc_attr_e( 'Explore topics', 'automotonews-future' ); ?>">
                <h3 class="footer-explore-title"><?php esc_html_e( 'Explore Topics', 'automotonews-future' ); ?></h3>
                <ul class="footer-explore-list">
                    <?php foreach ( $explore_links as $link ) : ?>
                    <li><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>

        <!-- Newsletter Signup -->
        <div class="footer-newsletter">
            <h3><?php esc_html_e( 'Subscribe for Daily Auto Updates', 'automotonews-future' ); ?></h3>
            <p><?php esc_html_e( 'Get the latest EV news, car launches, and bike reviews straight to your inbox.', 'automotonews-future' ); ?></p>
            <form class="newsletter-form" aria-label="<?php esc_attr_e( 'Newsletter signup', 'automotonews-future' ); ?>">
                <div class="newsletter-row">
                    <label class="screen-reader-text" for="newsletter-email"><?php esc_html_e( 'Email address', 'automotonews-future' ); ?></label>
                    <input type="email" id="newsletter-email" name="email" placeholder="<?php esc_attr_e( 'Enter your email', 'automotonews-future' ); ?>" required autocomplete="email">
                    <button type="submit" class="btn btn-primary"><?php esc_html_e( 'Subscribe', 'automotonews-future' ); ?></button>
                </div>
                <p class="newsletter-consent">
                    <label>
                        <input type="checkbox" id="newsletter-consent" name="consent" required>
                        <?php
                        printf(
                            wp_kses(
                                __( 'I agree to receive emails and accept the <a href="%s">Privacy Policy</a>.', 'automotonews-future' ),
                                array( 'a' => array( 'href' => array() ) )
                            ),
                            esc_url( amnf_page_url( array( 'privacy-policy' ), home_url( '/privacy-policy/' ) ) )
                        );
                        ?>
                    </label>
                </p>
                <p class="form-message" id="newsletter-msg" role="status" aria-live="polite"></p>
            </form>

            <nav class="footer-social" aria-label="<?php esc_attr_e( 'Social media links', 'automotonews-future' ); ?>">
                <?php foreach ( amnf_footer_social_links() as $network => $social ) : ?>
                <a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"
                   class="social-chip social-chip--<?php echo esc_attr( $network ); ?>"
                   aria-label="<?php echo esc_attr( $social['aria'] ); ?>">
                    <span class="social-chip-icon"><?php echo amnf_social_icon_svg( $network ); ?></span>
                    <span class="social-chip-label"><?php echo esc_html( $social['label'] ); ?></span>
                </a>
                <?php endforeach; ?>
            </nav>
        </div>

    </div>

    <!-- Copyright Bar -->
    <div class="copyright-bar">
        <div class="site-shell">
            <p>
                &copy; <?php echo date_i18n( 'Y' ); ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>.
                <?php esc_html_e( 'All rights reserved.', 'automotonews-future' ); ?>
                <?php esc_html_e( 'Content for informational purposes only.', 'automotonews-future' ); ?>
            </p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>

