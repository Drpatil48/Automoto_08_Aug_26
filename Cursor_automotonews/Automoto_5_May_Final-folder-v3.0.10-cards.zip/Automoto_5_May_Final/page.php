<?php
/**
 * Page Template — For static pages (About Us, Privacy Policy, Disclaimer, Contact)
 * @package AutoMotoNews_Future
 */
get_header();
while ( have_posts() ) : the_post();
?>
<main id="main-content" role="main" class="single-main site-shell">

  <!-- Breadcrumb -->
  <nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'automotonews-future' ); ?>">
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'automotonews-future' ); ?></a></li>
      <li class="breadcrumb-current" aria-current="page"><?php the_title(); ?></li>
    </ol>
  </nav>

  <article class="single-article page-article">

    <!-- Page Header -->
    <header class="article-header">
      <h1 class="article-title"><?php the_title(); ?></h1>
    </header>

    <!-- Featured Image -->
    <?php if ( has_post_thumbnail() ) : ?>
    <figure class="article-featured-image">
      <?php the_post_thumbnail( 'amnf-wide', array(
          'alt'     => get_the_title(),
          'loading' => 'eager',
      ) ); ?>
      <?php if ( get_the_post_thumbnail_caption() ) : ?>
        <figcaption><?php echo wp_kses_post( get_the_post_thumbnail_caption() ); ?></figcaption>
      <?php endif; ?>
    </figure>
    <?php endif; ?>

    <!-- Page Content -->
    <div class="article-content">
      <?php the_content(); ?>
      <?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'automotonews-future' ), 'after' => '</div>' ) ); ?>
    </div>

  </article>

  <!-- Comments (if enabled on the page) -->
  <?php if ( comments_open() || get_comments_number() ) : ?>
  <section class="comments-section glass" aria-label="<?php esc_attr_e( 'Comments', 'automotonews-future' ); ?>">
    <?php comments_template(); ?>
  </section>
  <?php endif; ?>

</main>

<?php endwhile; get_footer(); ?>
